﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L2Ex4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double b;
            double h;
            double area;


            Console.Write("Informe a Base do Retângulo (m): ");
            b = double.Parse(Console.ReadLine());

            Console.Write("Informe a altura do Retângulo (m): ");
            h = double.Parse(Console.ReadLine());

            area = b * h;

            Console.WriteLine("A Área do Retângulo Vale: {0} m²", area);
            if (area > 100)
            {
                Console.WriteLine("O Terreno é grande");
            }
        }
    }
}
