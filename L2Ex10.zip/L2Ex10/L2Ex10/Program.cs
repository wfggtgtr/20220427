﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L2Ex10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double np1;
            double np2;
            double media;


            Console.Write("Informe a Nota da P1: ");
            np1 = double.Parse(Console.ReadLine());

            Console.Write("Informe a Nota da P2: ");
            np2 = double.Parse(Console.ReadLine());


            media = (np1 + 2 * np2) / 3;

            Console.WriteLine("Média: {0:f1}", media);

            if (media >= 5)
            {
                Console.WriteLine("Aluno provado");
            }
            else
            {
                Console.WriteLine("Aluno reprovado");
            }
        }
    }
}
