﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L2Ex1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a;
            double b;

            Console.Write("Informe o primeiro Valor: ");
            a = double.Parse(Console.ReadLine());

            Console.Write("Informe o segundo Valor: ");
            b = double.Parse(Console.ReadLine());

            Console.WriteLine("");

            if (a > b)
            {
                Console.WriteLine("O primeiro valor informado é o Maior");
            }
            else
            {
                Console.WriteLine("O segundo valor informado é o maior");
            }
        }
    }
}
