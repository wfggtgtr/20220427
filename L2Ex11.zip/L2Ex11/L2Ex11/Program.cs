﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L2Ex11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double np1;
            double np2;

            Console.Write("Informe a Nota da P1: ");
            np1 = double.Parse(Console.ReadLine());

            Console.WriteLine("");

            np2 = (15 - (np1)) / 2;

            Console.WriteLine("O Aluno necessita tirar pelo menos {0} na P2 para estar aprovado.", np2);
        }
    }
}
